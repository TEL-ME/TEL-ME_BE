package com.telme.probe;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.telme.chat.config.ChatQuestionResolutionProperties.Mode;
import com.telme.chat.entity.ChatMessage;
import com.telme.chat.service.ChatContext;
import com.telme.chat.service.ChatContextMessage;
import com.telme.chat.service.ChatProcessingCommand;
import com.telme.chat.service.ChatQuestionResolver;
import com.telme.chat.service.ExecutionTrace;
import com.telme.llm.service.LlmClient;
import com.telme.llm.dto.req.LlmRequest;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;

class ContextReplayAuditTest {
    private static final Path ROOT = Path.of("/private/tmp/telme-exaone-reproduction");
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void checksRecordedResponsesAgainstOriginalValidationRulesWithoutModelCalls() throws Exception {
        JsonNode fixtures = mapper.readTree(Files.readString(
                Path.of("scripts/context-resolution-evaluation/cases.json")));
        Map<String, Object> audit = new LinkedHashMap<>();
        Map<String, JsonNode> originalRequests = new LinkedHashMap<>();
        Path originals = Path.of("/Users/choib/Downloads/reproduction-handoff/context-results");
        try (var directories = Files.list(originals)) {
            for (Path directory : directories.filter(p -> p.getFileName().toString().startsWith("c4-b-exaone1-"))
                    .filter(p -> !p.getFileName().toString().endsWith("holdoutCases")).toList()) {
                for (String line : Files.readAllLines(directory.resolve("model.jsonl"))) {
                    JsonNode original = mapper.readTree(line);
                    JsonNode request = original.path("request");
                    if (request.path("taskType").asText().equals("CONTEXT_RESOLUTION")) {
                        originalRequests.put(original.path("caseId").asText() + "|"
                                + request.path("promptVersion").asText(), request);
                    }
                }
            }
        }
        List<Map<String, Object>> requestChecks = new ArrayList<>();
        for (int round = 1; round <= 2; round++) {
            List<Map<String, Object>> records = new ArrayList<>();
            for (String line : Files.readAllLines(ROOT.resolve("results/context-" + round + ".jsonl"))) {
                JsonNode row = mapper.readTree(line);
                JsonNode fixture = null;
                for (JsonNode candidate : fixtures.path(row.path("key").asText())) {
                    if (candidate.path("id").asText().equals(row.path("id").asText())) {
                        fixture = candidate;
                        break;
                    }
                }
                assertThat(fixture).isNotNull();
                List<ChatContextMessage> history = new ArrayList<>();
                int sequence = 1;
                for (JsonNode text : fixture.path("history")) {
                    history.add(new ChatContextMessage(100L + sequence, sequence, ChatMessage.Role.USER,
                            ChatMessage.MessageType.QUESTION, text.asText(), null));
                    sequence++;
                }
                AtomicInteger index = new AtomicInteger();
                LlmClient client = mock(LlmClient.class);
                when(client.generate(any())).thenAnswer(invocation -> {
                    JsonNode call = row.path("calls").get(index.getAndIncrement());
                    assertThat(call).isNotNull();
                    assertThat(call.has("error")).isFalse();
                    LlmRequest actual = invocation.getArgument(0);
                    JsonNode old = originalRequests.get(row.path("id").asText() + "|" + actual.promptVersion());
                    assertThat(old).isNotNull();
                    requestChecks.add(Map.of("id", row.path("id").asText(),
                            "promptVersion", actual.promptVersion(),
                            "sameSystemPrompt", actual.systemPrompt().equals(old.path("systemPrompt").asText()),
                            "sameUserPromptBytes", actual.userPrompt().equals(old.path("userPrompt").asText()),
                            "sameUserPromptJson", mapper.readTree(actual.userPrompt()).equals(
                                    mapper.readTree(old.path("userPrompt").asText())),
                            "sameResponseSchema", mapper.valueToTree(actual.responseSchema()).equals(
                                    old.path("responseSchema")),
                            "sameMaxTokens", actual.maxTokens().intValue() == old.path("maxTokens").asInt(),
                            "sameTemperature", actual.temperature().doubleValue() == old.path("temperature").asDouble()));
                    return call.path("response").asText();
                });
                Map<String, Object> stages = new LinkedHashMap<>();
                ExecutionTrace trace = new ExecutionTrace() {
                    public void stage(Long executionId, String stage, Object value) {
                        stages.put(stage, value);
                    }

                    public void append(Long executionId, String stage, Object value) {
                    }
                };
                var resolver = new ChatQuestionResolver(client, mapper, trace, Mode.REGEX_GATED, false);
                String question = fixture.path("question").asText();
                var context = new ChatContext(1L, 999L, null, history, question, 100);
                var result = resolver.resolve(new ChatProcessingCommand(1L, 1L, 999L, question), context);
                String relation = result.needsClarification() ? "CLARIFICATION_REQUIRED"
                        : result.sourceMessageIds().isEmpty() ? "SELF_CONTAINED" : "HISTORY_DEPENDENT";
                assertThat(relation).isEqualTo(row.path("relation").asText());
                assertThat(index.get()).isEqualTo(row.path("calls").size());
                JsonNode resolution = mapper.valueToTree(stages.get("questionResolution"));
                String status = resolution.path("status").asText("");
                records.add(Map.of("id", row.path("id").asText(), "key", row.path("key").asText(),
                        "status", status, "valid", !List.of("INVALID_CONTEXT", "INVALID_RESOLUTION",
                                "MODEL_UNAVAILABLE").contains(status)));
            }
            assertThat(records).hasSize(243);
            audit.put("context-" + round, records);
        }
        Files.writeString(ROOT.resolve("results/context-replay-audit.json"),
                mapper.writerWithDefaultPrettyPrinter().writeValueAsString(audit));
        Files.writeString(ROOT.resolve("results/context-original-request-audit.json"),
                mapper.writerWithDefaultPrettyPrinter().writeValueAsString(requestChecks));
    }
}
