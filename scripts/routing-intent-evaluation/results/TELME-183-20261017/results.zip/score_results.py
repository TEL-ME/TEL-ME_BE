import collections
import gzip
import json
import math
from pathlib import Path
import statistics
import urllib.parse
import urllib.request

ROOT = Path('/private/tmp/telme-exaone-reproduction')
OUT = ROOT / 'results'
LABELS = ROOT / 'routing/scripts/data/eval_routing_unified.json'
items = {x['eval_id']: x for x in json.loads(LABELS.read_text())['items']}
search_cache = {}


def latency(values):
    values = sorted(values)
    return {'count': len(values), 'medianMs': statistics.median(values),
            'p95Ms': values[math.ceil(len(values) * .95) - 1]} if values else {}


def found(query):
    if query not in search_cache:
        url = 'http://127.0.0.1:18083/api/v1/faq/search?' + urllib.parse.urlencode({'query': query, 'topK': 1})
        with urllib.request.urlopen(url, timeout=120) as response:
            data = json.load(response)
        if data.get('isSuccess') is not True or not isinstance(data.get('result'), list):
            raise RuntimeError('Search correction requires a successful list response')
        search_cache[query] = {'found': bool(data['result']), 'response': data}
        (OUT / 'search-corrections.json').write_text(json.dumps(search_cache, ensure_ascii=False, indent=2))
    return search_cache[query]['found']


def intent(rows):
    cases = []
    for r in rows:
        final = r['intent']
        if r.get('model_intent') == 'UNKNOWN' and final == 'UNKNOWN':
            if found(r.get('resolved_question') or r['question']):
                final = 'FAQ'
        accepted = items[r['eval_id']]['acceptable_intents']
        cases.append({'id': r['eval_id'], 'actual': final, 'serviceIntent': r['intent'],
                      'modelIntent': r.get('model_intent'), 'correct': final in accepted,
                      'correctBeforeSearch': r['intent'] in accepted,
                      'compoundGuidance': r.get('compound_guidance', False)})
    return {'total': len(cases), 'correct': sum(x['correct'] for x in cases),
            'correctBeforeSearch': sum(x['correctBeforeSearch'] for x in cases),
            'latency': latency([x['elapsed_ms'] for x in rows]), 'cases': cases}


def inventory(rows):
    cases = []
    for r in rows:
        label = items[r['eval_id']]
        acceptable = label['acceptable_request_counts']
        count = r.get('request_count')
        correct = count in acceptable and r.get('decision') != 'FAILED'
        cases.append({'id': r['eval_id'], 'actual': count, 'decision': r.get('decision'),
                      'correct': correct, 'multiple': max(acceptable) > 1,
                      'error': r.get('error')})
    return {'total': len(cases), 'correct': sum(x['correct'] for x in cases),
            'multipleCorrect': sum(x['correct'] and x['multiple'] for x in cases),
            'singleCorrect': sum(x['correct'] and not x['multiple'] for x in cases),
            'latency': latency([x['elapsed_ms'] for x in rows]), 'cases': cases}


def route(rows):
    cases = []
    for r in rows:
        acceptable = items[r['eval_id']]['acceptable_request_counts']
        correct = not r.get('compound_guidance') and r['intent'] == 'FAQ' and r.get('sub_query_count') in acceptable
        cases.append({'id': r['eval_id'], 'actual': [r['intent'], r.get('sub_query_count'),
                                                   r.get('compound_guidance', False)],
                      'correct': correct, 'multiple': max(acceptable) > 1})
    return {'total': len(cases), 'correct': sum(x['correct'] for x in cases),
            'multipleCorrect': sum(x['correct'] and x['multiple'] for x in cases),
            'singleCorrect': sum(x['correct'] and not x['multiple'] for x in cases),
            'latency': latency([x['elapsed_ms'] for x in rows]), 'cases': cases}


def context(path):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line]
    audit_file = OUT / 'context-replay-audit.json'
    audit = json.loads(audit_file.read_text()).get(path.stem, []) if audit_file.exists() else []
    validation = {x['id']: x for x in audit}
    cases = []
    groups = collections.defaultdict(lambda: {'total': 0, 'correct': 0})
    all_calls = collections.defaultdict(list)
    for r in rows:
        valid = validation.get(r['id'], {}).get('valid', True)
        correct = (valid and r['relation'] == r['expectedRelation'] and
                   r['sourceIndexes'] == r['expectedSourceIndexes'] and 'error' not in r)
        groups[r['key']]['total'] += 1
        groups[r['key']]['correct'] += correct
        cases.append({'id': r['id'], 'key': r['key'], 'actual': [r['relation'], r['sourceIndexes']],
                      'correct': correct, 'error': r.get('error'),
                      'validationStatus': validation.get(r['id'], {}).get('status')})
        for c in r['calls']:
            all_calls[c['promptVersion']].append(c['ms'])
    basic = [v for k, v in groups.items() if k != 'blindCases']
    return {'total': len(rows), 'correct': sum(x['correct'] for x in cases),
            'basicCorrect': sum(x['correct'] for x in basic),
            'invalidResolutionCount': sum(not x['valid'] for x in audit),
            'groups': dict(groups), 'callLatency': {k: latency(v) for k, v in all_calls.items()},
            'cases': cases}


def compare(a, b):
    first = {x['id']: x for x in a['cases']}
    second = {x['id']: x for x in b['cases']}
    if first.keys() != second.keys():
        raise RuntimeError('Case identities differ between rounds')
    counts = collections.Counter()
    changed = []
    for key, x in first.items():
        y = second[key]
        counts['bothCorrect' if x['correct'] and y['correct'] else
               'bothWrong' if not x['correct'] and not y['correct'] else 'correctnessChanged'] += 1
        if x['actual'] != y['actual']:
            changed.append(key)
    return dict(counts) | {'decisionChanged': changed}


if __name__ == '__main__':
    if not (OUT / 'context-replay-audit.json').is_file():
        raise RuntimeError('Context replay validation audit is required before final scoring')
    if json.loads((OUT / 'active.json').read_text()).get('status') != 'complete':
        raise RuntimeError('Wait until every model evaluation has completed before scoring')
    # Free the completed generation model before loading local bge-m3 for correction.
    unload = urllib.request.Request('http://127.0.0.1:11436/api/generate',
                                    data=json.dumps({'model': 'exaone3.5:7.8b',
                                                     'keep_alive': 0, 'stream': False}).encode(),
                                    headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(unload, timeout=30) as response:
        (OUT / 'model-unload-before-search.json').write_text(response.read().decode())
    report = {'runs': {}, 'comparisons': {}}
    for n in (1, 2):
        report['runs'][f'context-{n}'] = context(OUT / f'context-{n}.jsonl')
    for stage, scorer in [('intent', intent), ('inventory', inventory), ('route-full', route)]:
        for n in (1, 2):
            records = json.loads((OUT / f'{stage}-{n}.json').read_text())['records']
            if len(records) != (365 if stage == 'intent' else 210) or len({r['eval_id'] for r in records}) != len(records):
                raise RuntimeError(f'{stage}-{n}: duplicate or missing records')
            report['runs'][f'{stage}-{n}'] = scorer(records)
    for stage in ('context', 'intent', 'inventory', 'route-full'):
        report['comparisons'][stage] = compare(report['runs'][f'{stage}-1'], report['runs'][f'{stage}-2'])
        if stage != 'context':
            records = [json.loads((OUT / f'{stage}-{n}.json').read_text())['records'] for n in (1, 2)]
            def normalized_response(row):
                raw = row.get('model_response') or ''
                try:
                    return json.loads(raw)
                except json.JSONDecodeError:
                    return raw
            first = {r['eval_id']: normalized_response(r) for r in records[0]}
            second = {r['eval_id']: normalized_response(r) for r in records[1]}
            report['comparisons'][stage]['recordedModelResponseChanged'] = [
                key for key in first if first[key] != second[key]]
    old_dir = ROOT / 'routing/scripts/routing-call-comparison/results'
    old_intent = json.loads(gzip.decompress((old_dir / 'step1-intent/results.json.gz').read_bytes()))
    old_inventory = json.loads(gzip.decompress((old_dir / 'step2-request-count/results.json.gz').read_bytes()))
    report['originalRescoredOnSuppliedDatabase'] = {
        'intent': intent(old_intent['exaone']['records']),
        'inventory': inventory(old_inventory['exaone']['records']),
        'route-full': route(old_inventory['exaone-full']['records']),
    }
    (OUT / 'scores.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({k: {x: v for x, v in d.items() if x not in ['cases', 'groups', 'callLatency']}
                      for k, d in report['runs'].items()}, ensure_ascii=False, indent=2))
