import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/private/tmp/telme-exaone-reproduction')
RESULTS = ROOT / 'results'
JAVA_HOME = '/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home'
BASE_ENV = {k: v for k, v in os.environ.items()
            if k in {'HOME', 'PATH', 'TMPDIR', 'LANG', 'LC_ALL', 'USER', 'LOGNAME', 'SHELL'}}
BASE_ENV['JAVA_HOME'] = JAVA_HOME


def run(name, checkout, test, settings):
    status = {'name': name, 'startedAt': time.time(), 'settings': settings}
    (RESULTS / 'active.json').write_text(json.dumps(status, indent=2))
    with (ROOT / (name + '.log')).open('w') as log:
        result = subprocess.run(['./gradlew', 'test', '--tests', test, '--rerun-tasks',
                                 '--offline', '--no-daemon'], cwd=ROOT / checkout,
                                env=BASE_ENV | settings, stdout=log, stderr=subprocess.STDOUT)
    status.update(finishedAt=time.time(), exitCode=result.returncode)
    (RESULTS / (name + '-execution.json')).write_text(json.dumps(status, indent=2))
    if result.returncode:
        raise RuntimeError(f'{name} failed: see {ROOT / (name + ".log")}')
    output = Path(settings.get('CONTEXT_PROBE_OUT', settings.get('TELME_ROUTING_OUT')))
    if not output.is_file():
        raise RuntimeError(f'{name}: output missing')
    print(name + ' completed', flush=True)


if __name__ == '__main__':
    # Context round 1 was started separately; require its complete output first.
    first = RESULTS / 'context-1.jsonl'
    deadline = time.monotonic() + 1800
    while not first.is_file() and time.monotonic() < deadline:
        time.sleep(2)
    if not first.is_file() or len(first.read_text().splitlines()) != 243:
        raise RuntimeError('context round 1 is not complete')
    run('context-2', 'context', 'com.telme.probe.ContextResolutionClientProbe', {
        'CONTEXT_PROBE': 'true', 'CONTEXT_PROBE_CLIENTS': 'router',
        'CONTEXT_PROBE_REPEATS': '1', 'CONTEXT_PROBE_GUARDS': 'false',
        'CONTEXT_PROBE_ROUTER_URL': 'http://127.0.0.1:11436',
        'CONTEXT_PROBE_OLLAMA_MODEL': 'exaone3.5:7.8b',
        'CONTEXT_PROBE_OUT': str(RESULTS / 'context-2.jsonl'),
    })
    for stage, input_name, step in [('intent', 'items.json', 'intent'),
                                     ('inventory', 'faq-items.json', 'inventory'),
                                     ('route-full', 'faq-items.json', 'intent')]:
        for round_number in (1, 2):
            name = f'{stage}-{round_number}'
            run(name, 'routing', 'com.telme.probe.RoutingEvaluationProbe', {
                'TELME_ROUTING_EVAL': 'true',
                'TELME_ROUTING_BASE_URL': 'http://127.0.0.1:11436',
                'TELME_ROUTING_INTENT_URL': 'http://127.0.0.1:11436',
                'TELME_ROUTING_INVENTORY_URL': 'http://127.0.0.1:11436',
                'TELME_ROUTING_FAITHFULNESS_URL': 'http://127.0.0.1:11436',
                'TELME_ROUTING_FOLLOWUP_URL': 'http://127.0.0.1:11436',
                'TELME_ROUTING_STEP': step, 'TELME_ROUTING_REPEATS': '1',
                'TELME_ROUTING_SKIP_INVENTORY': 'false',
                'TELME_ROUTING_INPUT': str(ROOT / 'routing' / input_name),
                'TELME_ROUTING_OUT': str(RESULTS / (name + '.json')),
            })
    (RESULTS / 'active.json').write_text(json.dumps({'status': 'complete'}))
